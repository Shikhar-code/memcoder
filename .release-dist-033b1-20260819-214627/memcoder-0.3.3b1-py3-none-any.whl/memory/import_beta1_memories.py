import json

from memory.capture import capture_memory


with open(
    "beta1_memories.json",
    "r",
    encoding="utf-8"
) as f:

    memories = json.load(f)


for memory in memories:

    capture_memory(
        task=memory["task"],
        files=memory["files"],
        summary=memory["summary"],
        solution=memory["solution"]
    )

    print(
        f"Stored: {memory['task']}"
    )

print(
    f"\nImported {len(memories)} memories"
)