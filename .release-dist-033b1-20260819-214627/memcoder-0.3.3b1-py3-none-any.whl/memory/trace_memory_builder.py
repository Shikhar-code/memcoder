import json
from pathlib import Path


def build_memory(example):

    file_name = Path(
        example["file"]
    ).name

    return {
        "task":
            example["problem"],

        "files":
            [file_name],

        "summary":
            f"Problem resolved in {file_name}.",

        "solution":
            example["solution_diff"]
    }


def build_memories(training_examples):

    memories = []

    for example in training_examples:

        memories.append(
            build_memory(example)
        )

    return memories

if __name__ == "__main__":

    with open(
        "training_examples.json",
        "r",
        encoding="utf-8"
    ) as f:

        examples = json.load(f)

    memories = build_memories(
        examples
    )

    with open(
        "beta1_memories.json",
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            memories,
            f,
            indent=2,
            ensure_ascii=False
        )

    print(
        f"Built {len(memories)} memories"
    )